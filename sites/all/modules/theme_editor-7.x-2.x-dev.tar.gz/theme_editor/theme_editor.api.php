<?php
/**
 * @file Defines the various hooks and API functions used and created in the Theme Editor module
 */