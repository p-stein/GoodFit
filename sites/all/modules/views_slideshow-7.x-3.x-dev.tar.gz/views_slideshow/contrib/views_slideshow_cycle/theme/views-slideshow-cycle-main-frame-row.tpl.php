<div id="views_slideshow_cycle_div_<?php print $variables['vss_id']; ?>_<?php print $variables['count']; ?>" class="<?php print $classes; ?>">
  <?php print $rendered_items; ?>
</div>
