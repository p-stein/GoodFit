<span id="views_slideshow_controls_text_previous_<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>"><a href="#"><?php print t('Previous'); ?></a></span>
