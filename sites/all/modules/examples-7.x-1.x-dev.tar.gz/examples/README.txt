
Examples modules

This set of modules is intended to show how to use various Drupal features.
It's intended only for developers.

If you find a problem, bad comment, poor usage, out-of-date API usage,
etc., please post an issue in the issue queue at
http://drupal.org/project/examples.


