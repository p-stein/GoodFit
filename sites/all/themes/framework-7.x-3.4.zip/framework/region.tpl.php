<?php
// $Id: region.tpl.php,v 1.1.2.2 2011/02/06 22:47:17 andregriffin Exp $
?>
<?php if (!empty($content)): ?>
<div class="<?php print $classes; ?>">
  <?php print $content; ?>
</div>
<?php endif; ?> <!-- /.region -->
